import pandas as pd
import numpy as np 

def load_dataset(classification):
  data = pd.read_csv("data/modbus_dataset.csv")
  data = data.sample(frac=1, random_state=1)
  cla = {'backdoor': 0, 'injection': 1, 'xss':2, 'password':3, 'scanning':4, 'normal':5}
  new_col = list()
  for i in list(data.type):
    new_col.append(cla[i])
  data['classes'] = new_col
  x_data = data.values[:, 3:7].astype(int)
  if classification == 'binary':
    y_data = np.asarray(list(data.label)).reshape(-1)
  elif classification == 'multi':
    y_data = np.asarray(list(data.classes)).reshape(-1)
  else:
    print('Please choose the correct classification type from "binary" or "multi"')

  cutoff = int(x_data.shape[0]*0.8)
  x_train, y_train = x_data[:cutoff], y_data[:cutoff]
  x_test, y_test = x_data[cutoff:], y_data[cutoff:]

  return x_train, y_train, x_test, y_test
